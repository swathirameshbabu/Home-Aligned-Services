import '/flutter_flow/flutter_flow_util.dart';
import 'order_placed_widget.dart' show OrderPlacedWidget;
import 'package:flutter/material.dart';

class OrderPlacedModel extends FlutterFlowModel<OrderPlacedWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
