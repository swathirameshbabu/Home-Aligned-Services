import '/flutter_flow/flutter_flow_util.dart';
import 'delete_confirmation_widget.dart' show DeleteConfirmationWidget;
import 'package:flutter/material.dart';

class DeleteConfirmationModel
    extends FlutterFlowModel<DeleteConfirmationWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
