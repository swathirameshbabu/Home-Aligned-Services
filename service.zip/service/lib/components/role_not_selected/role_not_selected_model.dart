import '/flutter_flow/flutter_flow_util.dart';
import 'role_not_selected_widget.dart' show RoleNotSelectedWidget;
import 'package:flutter/material.dart';

class RoleNotSelectedModel extends FlutterFlowModel<RoleNotSelectedWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
